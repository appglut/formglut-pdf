=== FormGlut PDF Add-on ===
Contributors: appglut
Requires at least: 5.0
Tested up to: 6.5.0
Requires PHP: 5.6
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Generate PDF from Your Form Submissions and you can also download and Email Them


