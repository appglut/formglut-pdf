<?php
/**
 * Plugin Name: FormGlut PDF Addon
 * Plugin URI:  https://appglut.com/formglut/
 * Description: Download submisstion data with PDF.
 * Author: AppGlut
 * Author URI:  https://appglut.com
 * Version: 1.0.0
 * Text Domain: formglut-pdf
 * Domain Path: /assets/languages
 */


defined('ABSPATH') or die;
define('FORMGLUT_PDF_VERSION', '1.0.0');
define('FORMGLUT_PDF_PATH', plugin_dir_path(__FILE__));
define('FORMGLUT_PDF_URL', plugin_dir_url(__FILE__));

class FormglutPdf
{
    public function boot()
    {
        if (!defined('FORMGLUT')) {
            return $this->injectDependency();
        }

        $this->includeFiles();

        if (function_exists('wpFormglut')) {
            return $this->registerHooks(wpFormglut());
        }
    }

    protected function includeFiles()
    {
        require_once FORMGLUT_PDF_PATH . 'Classes/Controller/AvailableOptions.php';
        require_once FORMGLUT_PDF_PATH . 'Classes/Controller/FontManager.php';
        require_once FORMGLUT_PDF_PATH . 'Classes/Controller/GlobalPdfManager.php';

        require_once FORMGLUT_PDF_PATH . 'Classes/Templates/TemplateManager.php';
        require_once FORMGLUT_PDF_PATH . 'Classes/Templates/GeneralTemplate.php';
        require_once FORMGLUT_PDF_PATH . 'Classes/Templates/InvoiceTemplate.php';
    }

    protected function registerHooks($formglut)
    {
        new \FormglutPdf\Classes\Controller\GlobalPdfManager($formglut);
    }


    /**
     * Notify the user about the Formglut dependency and instructs to install it.
     */
    protected function injectDependency()
    {
        add_action('admin_notices', function () {
            $pluginInfo = $this->getFormglutInstallationDetails();

            $class = 'notice notice-error';

            $install_url_text = __('Click Here to Install the Plugin', 'formglut-pdf');

            if ($pluginInfo->action == 'activate') {
                $install_url_text = __('Click Here to Activate the Plugin', 'formglut-pdf');
            }

            $message = __('Formglut pdf Add-On Requires FormGlut Plugin, ', 'formglut-pdf');
            $message .= '<b><a href="' .$pluginInfo->url . '">' . $install_url_text . '</a></b>';

            printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), wp_kses_post($message));
        });
    }

    protected function getFormglutInstallationDetails()
    {
        $activation = (object) [
            'action' => 'install',
            'url'    => ''
        ];

        $allPlugins = get_plugins();

        if (isset($allPlugins['formglut/formglut.php'])) {
            $url = wp_nonce_url(
                self_admin_url('plugins.php?action=activate&plugin=formglut/formglut.php'),
                'activate-plugin_formglut/formglut.php'
            );

            $activation->action = 'activate';
        } else {
            $api = (object) ['slug' => 'formglut'];

            $url = wp_nonce_url(
                self_admin_url('update.php?action=install-plugin&plugin=' . $api->slug),
                'install-plugin_' . $api->slug
            );
        }
        $activation->url = $url;
        return $activation;
    }
}

add_action('plugins_loaded', function () {

    load_plugin_textdomain(
        'formglut-pdf', false, basename(dirname(__FILE__)) . 'assets/languages'
    );

    (new FormglutPdf())->boot();
});

register_activation_hook(__FILE__, function () {
    require_once FORMGLUT_PDF_PATH . '/Classes/Controller/Activator.php';
    \FormglutPdf\Classes\Controller\Activator::activate();
});

register_deactivation_hook( __FILE__, function () {
    require_once FORMGLUT_PDF_PATH . '/Classes/Controller/Activator.php';
    \FormglutPdf\Classes\Controller\Activator::deactivate();
});
