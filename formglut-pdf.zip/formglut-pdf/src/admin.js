jQuery(document).ready(function ($) {
    let progress = 0;

    const pdfDownloader = {
        initDownloadFonts() {
            $('#fg_download_fonts').addClass('is-loading').attr('disabled', true);
            $('.fg_download_fonts_text').text('Downloading...');
            $('.fg_download_loading').html('Please do not close this window when downloading the fonts, After downloading page will auto reload.');

            this.ajaxLoadFonts();
        },

        ajaxLoadFonts() {

            if(progress < 95){
                progress += 5;
            }

            $(".fg_download_fonts_bar").animate({
                width: progress + '%'
            }, 1000);

            window.FormglutsGlobal.$post({
                action: 'formglut_pdf_admin_ajax_actions',
                route: 'downloadFonts'
            })

                .then(response => {
                    if(response.data.downloaded_files && response.data.downloaded_files.length) {
                        $('.fg_download_logs').prepend(response.data.downloaded_files.join('<br />')).show();
                        $('.fg_downlaod_logs').removeClass('hidden');
                        this.ajaxLoadFonts();
                    } else {
                        $(".fg_download_fonts_bar").animate({
                            width: '100%'
                        }, 1000);

                        // All Done
                        window.location.reload();
                    }
                })
                .fail(error => {
                    window.location.reload();
                });
        },

        init() {
            $('#fg_download_fonts').on('click', (e) => {
                e.preventDefault();
                this.initDownloadFonts();
            });
        }
    };

    pdfDownloader.init();
});