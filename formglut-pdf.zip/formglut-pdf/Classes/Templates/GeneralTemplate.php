<?php

namespace FormglutPdf\Classes\Templates;

use Formglut\App\Services\Emogrifier\Emogrifier;
use Formglut\App\Services\FormBuilder\ShortCodeParser;
use Formglut\Framework\Foundation\Application;
use FormglutPdf\Classes\Templates\TemplateManager;
use Formglut\Framework\Helpers\ArrayHelper as Arr;
use FormglutPdf\Classes\Controller\AvailableOptions as PdfOptions;


class GeneralTemplate extends TemplateManager
{

    public $headerHtml = '';

    public function __construct(Application $app)
    {
        parent::__construct($app);

    }

    public function getDefaultSettings($form)
    {
        return [
            'header' => '<h2>PDF Title</h2>',
            'footer' => '<table width="100%"><tr><td width="50%">{DATE j-m-Y}</td><td width="50%"  style="text-align: right;" align="right">{PAGENO}/{nbpg}</td></tr></table>',
            'body'   => '{all_data}'
        ];
    }

    public function getSettingsFields()
    {
        return array(
            [
                'key'       => 'header',
                'label'     => __('Header Content', 'formglut-pdf'),
                'tips'      => __('Write your header content which will be shown every page of the PDF', 'formglut-pdf'),
                'component' => 'wp-editor'
            ],
            [
                'key'        => 'body',
                'label'      => __('PDF Body Content', 'formglut-pdf'),
                'tips'       => __('Write your Body content for actual PDF body', 'formglut-pdf'),
                'component'  => 'wp-editor',
                'inline_tip' => defined('FORMGLUTPRO') ?
                    sprintf(__('You can use Conditional Content in PDF body, for details please check this %s. ',
                        'formglut-pdf'),
                        '<a target="_blank" href="https://wpmanageninja.com/docs/formg-form/advanced-features-functionalities-in-wp-formg-form/conditional-shortcodes-in-email-notifications-form-confirmation/">Documentation</a>') : __('Conditional PDF Body Content is supported in Formg Forms Pro Version',
                        'formglut-pdf'),

            ],
            [
                'key'        => 'footer',
                'label'      => __('Footer Content', 'formglut-pdf'),
                'tips'       => __('Write your Footer content which will be shown every page of the PDF', 'formglut-pdf'),
                'component'  => 'wp-editor',
                'inline_tip' => __('Write your Footer content which will be shown every page of the PDF', 'formglut-pdf'),

            ]
        );
    }

    public function generatePdf($submissionId, $feed, $outPut = 'I', $fileName = '')
    {
        $settings = $feed['settings'];
        $submission = wpFormg()->table('formglut_submissions')
            ->where('id', $submissionId)
            ->first();
        $formData = json_decode($submission->response, true);

        $settings = ShortCodeParser::parse($settings, $submissionId, $formData, null, false, 'pdfFeed');

        if (!empty($settings['header'])) {
            $this->headerHtml = $settings['header'];
        }

        $htmlBody = $settings['body'];  // Inserts HTML line breaks before all newlines in a string

        $form = wpFormg()->table('formglut_forms')->find($submission->form_id);

        $htmlBody = apply_filters_deprecated(
            'fg_pdf_body_parse',
            [
                $htmlBody,
                $submissionId,
                $formData,
                $form
            ],
            FORMGLUT_FRAMEWORK_UPGRADE,
            'formglut/pdf_body_parse',
            'Use formglut/pdf_body_parse instead of fg_pdf_body_parse.'
        );

        $htmlBody = apply_filters('formglut/pdf_body_parse', $htmlBody, $submissionId, $formData, $form);

        $footer = $settings['footer'];

        if (!$fileName) {
            $fileName = ShortCodeParser::parse($feed['name'], $submissionId, $formData);
            $fileName = sanitize_title($fileName, 'pdf-file', 'display');
        }

        return $this->pdfBuilder($fileName, $feed, $htmlBody, $footer, $outPut);
    }
}
